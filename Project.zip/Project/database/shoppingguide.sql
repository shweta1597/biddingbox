/*
SQLyog Enterprise v12.4.3 (64 bit)
MySQL - 10.1.30-MariaDB : Database - shoppingguide
*********************************************************************
*/

/*!40101 SET NAMES utf8 */;

/*!40101 SET SQL_MODE=''*/;

/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
CREATE DATABASE /*!32312 IF NOT EXISTS*/`shoppingguide` /*!40100 DEFAULT CHARACTER SET latin1 */;

USE `shoppingguide`;

/*Table structure for table `admin` */

DROP TABLE IF EXISTS `admin`;

CREATE TABLE `admin` (
  `user_name` varchar(50) NOT NULL,
  `password` varchar(30) DEFAULT NULL,
  `email` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`user_name`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `admin` */

insert  into `admin`(`user_name`,`password`,`email`) values 
('anuja','123456789','anuja@gmail.com');

/*Table structure for table `business` */

DROP TABLE IF EXISTS `business`;

CREATE TABLE `business` (
  `business_name` varchar(50) NOT NULL,
  `address` varchar(100) NOT NULL,
  `area` varchar(50) NOT NULL,
  `city` varchar(50) NOT NULL,
  `description` varchar(1000) NOT NULL,
  `email` varchar(50) NOT NULL,
  `contact_no` varchar(30) NOT NULL,
  `latitude` varchar(30) NOT NULL,
  `longitude` varchar(30) NOT NULL,
  `working_days` varchar(40) NOT NULL,
  `timings` varchar(30) NOT NULL,
  `category` varchar(50) NOT NULL,
  `website` varchar(100) NOT NULL,
  `businessid` varchar(100) NOT NULL,
  PRIMARY KEY (`businessid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `business` */

insert  into `business`(`business_name`,`address`,`area`,`city`,`description`,`email`,`contact_no`,`latitude`,`longitude`,`working_days`,`timings`,`category`,`website`,`businessid`) values 
('electro','maruti road','old gandhi nagar','belagavi','all electronics stuff','anujakalmani@gmail.com','8867891001','','','7','7:00am-9:00pm','electronics','http://example.com ','');

/*Table structure for table `business_photos` */

DROP TABLE IF EXISTS `business_photos`;

CREATE TABLE `business_photos` (
  `photo_id` int(50) NOT NULL AUTO_INCREMENT,
  `photo_file_name` varchar(50) DEFAULT NULL,
  `description` varchar(500) DEFAULT NULL,
  `Businessuname` varchar(50) NOT NULL,
  PRIMARY KEY (`photo_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `business_photos` */

/*Table structure for table `businessowner` */

DROP TABLE IF EXISTS `businessowner`;

CREATE TABLE `businessowner` (
  `firstname` varchar(50) NOT NULL,
  `lastname` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `mobileno` varchar(20) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `businessowner` */

insert  into `businessowner`(`firstname`,`lastname`,`email`,`mobileno`,`username`,`password`) values 
('Anuja ','lastname','anujakalmani@gmail.com','8867891001','anuja','123456789'),
('amruta','lastname','amruta@gmail.com','7234567891','amu','123456789'),
('Deepa','lastname','deepakulkarni@gmail.com','8550857978','dips','123456789');

/*Table structure for table `category` */

DROP TABLE IF EXISTS `category`;

CREATE TABLE `category` (
  `category_name` varchar(30) NOT NULL,
  PRIMARY KEY (`category_name`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `category` */

/*Table structure for table `products` */

DROP TABLE IF EXISTS `products`;

CREATE TABLE `products` (
  `product_id` int(30) NOT NULL AUTO_INCREMENT,
  `product_name` varchar(50) DEFAULT NULL,
  `description` varchar(1000) DEFAULT NULL,
  `price` decimal(20,0) DEFAULT NULL,
  `Businessuname` varchar(50) NOT NULL,
  PRIMARY KEY (`product_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `products` */

/*Table structure for table `review` */

DROP TABLE IF EXISTS `review`;

CREATE TABLE `review` (
  `id` int(50) NOT NULL AUTO_INCREMENT,
  `rating` int(10) DEFAULT NULL,
  `comments` varchar(500) DEFAULT NULL,
  `review_date_time` datetime DEFAULT NULL,
  `reviewtype` varchar(20) NOT NULL,
  `username` varchar(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `review` */

/*Table structure for table `visitor` */

DROP TABLE IF EXISTS `visitor`;

CREATE TABLE `visitor` (
  `user_name` varchar(50) NOT NULL,
  `password` varchar(30) DEFAULT NULL,
  `full_name` varchar(100) DEFAULT NULL,
  `address` varchar(100) DEFAULT NULL,
  `email` varchar(50) DEFAULT NULL,
  `mobile_number` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`user_name`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `visitor` */

insert  into `visitor`(`user_name`,`password`,`full_name`,`address`,`email`,`mobile_number`) values 
('anuja','123456789','Anuja Kalmani','Old gandhi nagar,Belagavi','anujakalmani@gmail.com','8867891001'),
('rakshu','123456789','Rakshita Padaki','modga','rakshitapadaki@gmail.com','7022441846');

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
