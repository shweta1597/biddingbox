<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Untitled Document</title>
</head>

<body>
<table width="404" border="0" align="center" cellpadding="10" cellspacing="0">
  <tbody>
    <tr>
      <td colspan="2" align="center"><strong style="font-size: x-large">FORGOT PASSWORD</strong></td>
    </tr>
    <tr>
      <td width="131"><strong>User Name</strong></td>
      <td width="227"><strong>
        <input type="text" name="textfield" id="textfield">
      </strong></td>
    </tr>
    <tr>
      <td><strong>Email</strong></td>
      <td><strong>
        <input type="text" name="textfield2" id="textfield2">
      </strong></td>
    </tr>
  </tbody>
</table>
<table width="500" border="0" align="center" cellpadding="10" cellspacing="0">
  <tbody>
    <tr>
      <td align="center"><p>
        <input type="submit" name="submit" id="submit" value="GET YOUR PASSWORD">
      </p>
      <p><a href="login.php"><strong>Back to Login </strong></a></p></td>
    </tr>
  </tbody>
</table>
<p>&nbsp;</p>
</body>
</html>