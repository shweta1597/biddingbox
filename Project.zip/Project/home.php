<!doctype html>
 <html>
  <head>
   <meta charset="utf-8">
	<title> Home </title>
	 <link href="menustyle.css" rel="stylesheet" type="text/css">
	  <style type="text/css">
		body 
		{
	background-image: url(code-wallpaper-24.jpg);
	margin-left: 2px;
	margin-top: 2px;
	margin-right: 2px;
	margin-bottom: 2px;
		}
      </style>
   </head>
   <body>
    <p>&nbsp;</p>
    <div class="container">
     <table align="center" width="1000" border="0" cellspacing="0" cellpadding="0">
      <tbody>
        <tr>
          <td bgcolor="#FFFFFF"> <?php include("header.php"); ?></td>
        </tr>
        <tr>
          <td bgcolor="#FFFFFF"> <?php include("navmenu.php"); ?></td>
        </tr>
        <tr>
          <td bgcolor="#FFFFFF">
           <table width="1000" border="0" cellspacing="0" cellpadding="10">
            <tbody>
              <tr>
                <td><form id="form1" name="form1" method="post">
                 <p>&nbsp;</p>
                  <img src="quote1.jpg" width="979" height="359" alt=""/>
                  <table width="400" border="0" align="center" cellpadding="10" cellspacing="2" >
                  
                  </table>
                 <p>&nbsp;</p>
                </form></td>
                </tr>
            </tbody>
          </table></td>
        </tr>
        <tr>
          <td bgcolor="#FFFFFF"> <?php include("footer.php"); ?></td>
        </tr>
      </tbody>
    </table>
   </div>
  </body>
</html>