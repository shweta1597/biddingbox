<!doctype html>
 <html>
  <head>
   <meta charset="utf-8">
    <title> Bidding Box </title>
	 <link href="menustyle.css" rel="stylesheet" type="text/css">
	  <style type="text/css">
	  body 
	  {
			background-image: url(code-wallpaper-24.jpg);
			margin-left: 2px;
			margin-top: 2px;
			margin-right: 2px;
			margin-bottom: 2px;
	  }
	  </style>
   </head>
   <body>
   <p>&nbsp;</p>
    <div class="container">
    <table align="center" width="1000" border="0" cellspacing="0" cellpadding="0">
     <tbody>
      <tr>
        <td bgcolor="#FFFFFF"> <?php include("header.php"); ?></td>
      </tr>
	  <tr>
        <td bgcolor="#FFFFFF"> <?php include("navmenu.php"); ?></td>
      </tr>
      <tr>
        <td bgcolor="#FFFFFF">
          <table width="1000" border="0" cellspacing="0" cellpadding="10">
           <tbody>
            <tr>
              <td>              
                <p>&nbsp;</p>
                <table align="center" width="961" height="261" border="0" cellpadding="10" cellspacing="0">
                  <tbody>
                    <tr>
                      <td><img src="giphy.gif" width="300" height="288" alt=""/></td>
                      <td><img src="admin.png" width="300" height="288" alt=""/></td>
                      <td> <img src="img-header.gif" width="300" height="288" alt=""/></td>
                    </tr>
                    <tr>
                      <td width="300"><h2 align="center"> Coder </h2></td>
                      <td width="289"><h2 align="center"> Admin </h2></td>
                      <td width="312"><h2 align="center"> Buyer </h2></td>
                    </tr>
                  </tbody>
          		</table>
                <p>&nbsp;</p>
              </td>
             </tr>
          </tbody>
        </table>
       </td>
      </tr>
      <tr>
        <td bgcolor="#FFFFFF"> <?php include("footer.php"); ?></td>
      </tr>
    </tbody>
  </table>
  </div>
 </body>
</html>