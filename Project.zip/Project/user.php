<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Untitled Document</title>
<style type="text/css">
body {
	background-image: url(images/background.jfif);
	text-align: center;
}

</style>
<link href="navigate_menu.css" rel="stylesheet" type="text/css">
</head>

<body>

<p>&nbsp;</p>
<table width="1000" border="0" align="center" cellpadding="0" cellspacing="0">
  <tbody>
    <tr>
      <td bgcolor="#FFFFFF"><?php include("header.php"); ?></td>
    </tr>
    <tr>
      <td bgcolor="#FFFFFF"><?php include("navigate_menu.php"); ?></td>
    </tr>
    <tr>
      <td bgcolor="#FFFFFF"><form action="user_back.php" method="post" name="form1" id="form1">
        <table width="400" border="0" align="center" cellpadding="10" cellspacing="0">
          <tbody>
            <tr>
              <td colspan="2"><strong style="font-size: 24px">User Registration <span style="text-align: center">Form</span></strong></td>
            </tr>
            <tr>
              <td width="151">Full Name</td>
              <td width="209"><input name="fullname" type="text" required id="fullname" pattern="[a-zA-Z\s]+" title="Accepts lower case, upper case and space"></td>
            </tr>
            <tr>
              <td>Email</td>
              <td><input name="email" type="email" required="required" id="email" title="eg: xyz@gmail.com"></td>
            </tr>
            <tr>
              <td><p>Mobile No</p></td>
              <td><input name="mobileno" type="tel" required="required" id="mobileno" pattern="(9|8|7)\d{9}" title="Number starts from 9 or 8 or 7 and 10 characters are required"></td>
            </tr>
            <tr>
              <td>Address</td>
              <td><textarea name="address" required="required" id="address"></textarea></td>
            </tr>
            <tr>
              <td>Username</td>
              <td><input name="uname" type="text" required id="uname" pattern="[a-z]{1,20}" title="Only lower case letters and minimum 1 maximum 20 characters"></td>
            </tr>
            <tr>
              <td>Password</td>
              <td><input name="pass" type="password" required id="pass" pattern="[a-zA-Z0-9@$#!]{8,20}" title="lower case,upper case,@,$,#,! special symbols and minimum 8 maximum 20 characters"></td>
            </tr>
            <tr>
              <td>Confirm Password</td>
              <td><input name="conpass" type="password" required id="conpass" pattern="[a-zA-Z0-9@$#!]{8,20}" title="lower case,upper case,@,$,#,! special symbols and minimum 8 maximum 20 characters"></td>
            </tr>
            <tr>
              <td>&nbsp;</td>
              <td><input type="submit" name="submit" id="submit" value="Submit"></td>
            </tr>
          </tbody>
        </table>
      </form></td></tr><tr>
      <td bgcolor="#FFFFFF"><?php include("footer.php"); ?></td>
    </tr>

  </tbody>
</table>
</body>
</html>