<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
</head>

<body>
<?php

   //establish a connection with database
  include("myconn.php");
  //accept the values from user form and then store it in variables
  $rollno = $_REQUEST["rollno"];
  $fullname = $_REQUEST["fullname"];
  $course = $_REQUEST["course"];
  $sem = $_REQUEST["sem"];
  $email = $_REQUEST["email"];
  $uname = $_REQUEST["uname"];
  $pass = $_REQUEST["pass"];
  
  //create a insert query
  $insertquery="INSERT INTO student (rollno,fullname,course,sem,email,uname,pass) values('$rollno','$fullname','$course','$sem','$email','$uname','$pass')";
  
  //execute the query
  if ($conn->query($insertquery) === TRUE) 
  {
     echo "</br> Registration Successfull";
  } 
  else 
  {
    echo "Error: " . $conn->error;
  }

	//close the connection
	$conn->close();
  
 
?>
</body>
</html>