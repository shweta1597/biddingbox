<?php
session_start();
ob_start();
if(!isset($_SESSION["uname"]))
{
	header("location:businessownerlogin.php");
}
?>
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title></title>
<style type="text/css">
body {
	background-image: url(images/background.jfif);
}
</style>
<link href="navigate_menu.css" rel="stylesheet" type="text/css">
</head>
<body>
<table width="1000" border="0" align="center" cellpadding="0" cellspacing="0">
  <tbody>
    <tr>
      <td bgcolor="#FFFFFF"><?php include("header.php"); ?></td>
    </tr>
    <tr>
      <td bgcolor="#FFFFFF"><?php include("adminmenu.php"); ?></td>
    </tr>
    <tr>
      <td bgcolor="#FFFFFF"><table width="1102" border="0" cellspacing="0" cellpadding="10">
        <tbody>
          <tr>
            <td width="1082"><table width="1172" border="1" align="center" cellpadding="10" cellspacing="0">
              <tbody>
                <tr>
                  <td width="122">Username</td>
                  <td width="122">Password</td>
                  <td width="174">Email</td>
                  <td width="98">Edit</td>
                  <td width="127">Delete</td>
                </tr>
                <?php
     					include("myconn.php");
						$sql = "SELECT * from businessowner";
						$result=$conn->query($sql);
						while($row = $result->fetch_assoc())
						{
   								$username=$row["username"];
				 ?>
                <tr>
                  <td> <?php echo $username ?> </td>
				  
				  <td> <?php echo $row["password"]; ?> </td>
				  <td> <?php echo $row["email"]; ?> </td>
                  <td>Edit </td>
                  <td>Delete</td>
                </tr>
                <?php
					}
				?>
              </tbody>
            </table></td>
          </tr>
        </tbody>
      </table></td>
    </tr>
    <tr>
      <td bgcolor="#FFFFFF"><?php include("footer.php"); ?></td>
    </tr>
  </tbody>
</table>
</body>
</html>