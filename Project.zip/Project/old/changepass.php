<!doctype html>
 <html>
  <head>
   <meta charset="utf-8">
	<title> Change Password </title>
	 <style type="text/css">
       body
       {
           background-image: url(code-wallpaper-24.jpg);
       }
     </style>
	<link href="menustyle.css" rel="stylesheet" type="text/css">
   </head>
   <body>
    <p>&nbsp;</p>
     <div class="container">
      <table align="center" width="1000" border="0" cellspacing="0" cellpadding="0">
       <tbody>
        <tr>
          <td bgcolor="#FFFFFF"> <?php include("header.php"); ?> </td>
        </tr>
        <tr>
          <td bgcolor="#FFFFFF"> <?php include("navmenu.php"); ?> </td>
        </tr>
        <tr>
          <td bgcolor="#FFFFFF">
           <table width="1000" border="0" cellspacing="0" cellpadding="10">
            <tbody>
              <tr>
                <td><form id="form1" name="form1" method="post">
                  <p>&nbsp;</p>
                  <table align="center" width="396" border="0" cellspacing="10" cellpadding="5">
                    <tbody>
                      <tr>
                        <td width="154">Old Password</td>
                        <td width="192"><input type="password" name="password" id="password"></td>
                      </tr>
                      <tr>
                        <td>New Password</td>
                        <td><input type="password" name="newpassword" id="newpassword"></td>
                      </tr>
                      <tr>
                        <td>Confirm Password</td>
                        <td><input type="password" name="confirmpassword" id="confirmpassword"></td>
                      </tr>
                      <tr>
                        <td>&nbsp;</td>
                        <td><input type="submit" name="submit" id="submit" value="Submit"></td>
                      </tr>
                    </tbody>
                  </table>
                  <p>&nbsp;</p>
                  </form>
                 </td>
                </tr>
               </tbody>
              </table>
             </td>
            </tr>
           </tbody>
          </table>
         </div>
        </body>
       </html>
  <?php
	if($_SERVER["REQUEST_METHOD"] == "POST")
	{
		//establish connection
		include ("myconn.php");
		
		//accept the values from user form
		$pass=$_REQUEST["password"];
		$npass=$_REQUEST["newpassword"];
		$cpass=$_REQUEST["confirmpassword"];
	 
		echo " Your password : " . $_REQUEST["password"];
		echo " </br> New Password : " . $_REQUEST["newpassword"];
		echo " </br> Confirm password : " . $_REQUEST["confirmpassword"];
		
	}
?>

