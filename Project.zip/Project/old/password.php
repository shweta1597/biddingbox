<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Untitled Document</title>
</head>

<body>
<form action="password_back.php" method="post" name="form1" id="form1">
  <table width="396" border="0" cellspacing="10" cellpadding="5">
    <tbody>
      <tr>
        <td width="154">Old Password</td>
        <td width="192"><input type="password" name="oldpassword" id="oldpassword"></td>
      </tr>
      <tr>
        <td>New Password</td>
        <td><input type="password" name="newpassword" id="newpassword"></td>
      </tr>
      <tr>
        <td>Confirm Password</td>
        <td><input type="password" name="confirmpassword" id="confirmpassword"></td>
      </tr>
      <tr>
        <td>&nbsp;</td>
        <td><input type="submit" name="submit" id="submit" value="Submit"></td>
      </tr>
    </tbody>
  </table>
  <p>&nbsp;</p>
</form>
</body>
</html>