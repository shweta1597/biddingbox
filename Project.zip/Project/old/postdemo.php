<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title> PostDemo </title>
</head>

<body>
<form action="postdemo_back.php" method="post" name="form1" id="form1">
  <table width="500" border="0" align="center" cellpadding="20" cellspacing="15">
    <tbody>
      <tr>
        <td>Name</td>
        <td><input type="text" name="fullname" id="fullname"></td>
      </tr>
      <tr>
        <td>Email</td>
        <td><input type="email" name="email" id="email"></td>
      </tr>
      <tr>
        <td>&nbsp;</td>
        <td><input type="submit" name="submit" id="submit" value="submit"></td>
      </tr>
    </tbody>
    <tbody>
    </tbody>
  </table> 
 </form>
</body>
</html>