<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title> upload_demo </title>
</head>

<body>
<form method="post" enctype="multipart/form-data" name="form1" id="form1">
  <p>&nbsp;</p>
  <p>
    <label for="profilephoto">Search a File:</label>
    <input type="file" name="profilephoto" id="profilephoto">
    <input type="submit" name="submit" id="submit" value="Submit">
  </p>
  <p>&nbsp;</p>
</form>
</body>
</html>

<?php 
if($_SERVER['REQUEST_METHOD']=="POST")
{
	include("myconn.php"); 
	$errors = array();
 	$file_name = $_FILES['profilephoto']['name'];
	$file_size = $_FILES['profilephoto']['size'];
	$file_tmp = $_FILES['profilephoto']['tmp_name'];
	$file_type = $_FILES['profilephoto']['type'];
	
	$allowed = array("jpg" => "image/jpg", "jpeg" => "image/jpeg", "gif" => "image/gif", "png" => "image/png", "pdf" => "document/pdf");
	
	// Verify file extension
	
	$ext = pathinfo($file_name, PATHINFO_EXTENSION);
	
	if(!array_key_exists($ext, $allowed)) die("Error: Please select valid file format. ");
	move_uploaded_file($file_tmp,"uploads/".$file_name);
	
}
?>