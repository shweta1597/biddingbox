<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title> GetDemo_Back </title>
</head>

<body>
<?php 
	$str = $_GET["str"];
	echo $str;
?>
</body>
</html>