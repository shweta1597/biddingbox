  <table width="1000" border="0" cellspacing="0" cellpadding="0">
    <tbody>
      <tr>
        <td> <img src="biddingbox.jpg" width="1000" height="230" alt=""/> </td>
      </tr>
    </tbody>
  </table>
