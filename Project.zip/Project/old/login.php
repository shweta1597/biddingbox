<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Untitled Document</title>
</head>

<body>
<form action="login_back.php" method="post" name="form1" id="form1">
  <table width="400" border="0" align="center" cellpadding="15" cellspacing="5">
    <tbody>
      <tr>
        <td colspan="2">Login Form</td>
      </tr>
      <tr>
        <td>Username </td>
        <td><input type="text" name="username" id="username"></td>
      </tr>
      <tr>
        <td>Pssword</td>
        <td><input type="text" name="password" id="password"></td>
      </tr>
      <tr>
        <td>&nbsp;</td>
        <td><input type="submit" name="submit" id="submit" value="Sign In"></td>
      </tr>
      <tr>
        <td>&nbsp;</td>
        <td><a href="password.php">Forgot Password?</a></td>
      </tr>
      <tr>
        <td>&nbsp;</td>
        <td><a href="student_register.php">New User? Register</a></td>
      </tr>
    </tbody>
  </table>
  <p>&nbsp;</p>
</form>
</body>
</html>

