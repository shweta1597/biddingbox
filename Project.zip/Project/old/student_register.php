<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Untitled Document</title>
</head>

<body>
<form action="" method="post" name="form1" id="form1">
  <table width="424" border="0" align="center" cellpadding="5" cellspacing="10">
    <tbody>
      <tr>
        <td colspan="2">Registration Form</td>
      </tr>
      <tr>
        <td width="154">Roll No.</td>
        <td width="210"><input name="rollno" type="text" required="required" id="rollno"></td>
      </tr>
      <tr>
        <td>Full Name</td>
        <td><input type="text" name="fullname" id="fullname"></td>
      </tr>
      <tr>
        <td>Course</td>
        <td><select name="course" id="course">
          <option value="BBA">BBA</option>
          <option value="BCA">BCA</option>
        </select></td>
      </tr>
      <tr>
        <td>Semester</td>
        <td><select name="sem" id="sem">
            <option value="1">1</option>
            <option value="2">2</option>
            <option value="3">3</option>
            <option value="4">4</option>
            <option value="5">5</option>
            <option value="6">6</option>
        </select></td>
      </tr>
      <tr>
        <td>Email</td>
        <td><input type="email" name="email" id="email"></td>
      </tr>
      <tr>
        <td>Username</td>
        <td><input type="text" name="username" id="username"></td>
      </tr>
      <tr>
        <td>Password</td>
        <td><input type="password" name="password" id="password"></td>
      </tr>
      <tr>
        <td>Confirm Password</td>
        <td><input type="password" name="confirmpassword" id="confirmpassword"></td>
      </tr>
      <tr>
        <td>&nbsp;</td>
        <td><input type="submit" name="submit" id="submit" value="submit"></td>
      </tr>
    </tbody>
  </table>
</form>
</body>
</html>

<?php 
	
	if($_SERVER["REQUEST_METHOD"] == "POST")
	{
		$rollno=$_REQUEST["rollno"];
		$fullname=$_REQUEST["fullname"];
		$course=$_REQUEST["course"];
		$sem=$_REQUEST["sem"];
		$email=$_REQUEST["email"];
		$uname=$_REQUEST["username"];
		$pass=$_REQUEST["password"];
		
		include("myconn.php");
	
		$sql="Select * from student where username='$uname'";
		$result = $conn->query($sql);
		if($result->num_rows >=1 )
		{
			  echo "User Already Registered";
		}
		else if($result->num_rows ==0 )
		{
				$insertquery = "INSERT INTO student(rollno,fullname,course,sem,email,username,password) values('$rollno','$fullname','$course','$sem','$email','$uname','$pass')";
				   
				if($conn->query($insertquery)===TRUE)
				{
					echo " </br> Register successful ";
				}
				else
				{
					echo "Error : " . $sql . "<br>" . $conn->error;
				}
		}
		else
		{
			echo "Error : " . $sql . "<br>" . $conn->error;
		}
		
	$conn->close();
	}
?>