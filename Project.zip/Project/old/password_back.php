<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Untitled Document</title>
</head>

<body>
<?php 
	echo " Your password : " . $_REQUEST["oldpassword"];
	echo " </br> New Password : " . $_REQUEST["newpassword"];
	echo " </br> Confirm password : " . $_REQUEST["confirmpassword"];
?>
</body>
</html>