<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title> PostDemoBack </title>
</head>

<body>
<?php 
	echo " Welcome : ".$_POST["fullname"];
	echo "<br> Your Email address is : ".$_POST["email"];
?>
</body>
</html>