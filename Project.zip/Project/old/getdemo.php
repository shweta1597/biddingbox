<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title> GetDemo </title>
</head>

<body>
<form action="getdemo_back.php" method="get" name="form1" id="form1">
<label for="str"> Enter a string : </label>
<input type="text" name="str" id="str">
<input type="submit" name="submit" id="submit" value="send">
</form>
</body>
</html>