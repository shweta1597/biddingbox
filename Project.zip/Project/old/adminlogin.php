<!doctype html>
 <html>
  <head>
   <meta charset="utf-8">
    <title> Admin Login </title>
	 <link href="menustyle.css" rel="stylesheet" type="text/css">
	  <style type="text/css">
        body
        {
            background-image: url(code-wallpaper-24.jpg);
        }
      </style>
   </head>
   <body>
    <p>&nbsp;</p>
     <div class="container">
      <table align="center" width="1000" border="0" cellspacing="0" cellpadding="0">
       <tbody>
        <tr>
          <td bgcolor="#FFFFFF"> <?php include("header.php"); ?> </td>
        </tr>
        <tr>
          <td bgcolor="#FFFFFF"> <?php include("navmenu.php"); ?> </td>
        </tr>
        <tr>
          <td bgcolor="#FFFFFF">
           <table width="1000" border="0" cellspacing="0" cellpadding="10">
            <tbody>
              <tr>
               <td>
                <form id="form1" name="form1" method="post">
                  <p>&nbsp;</p>
                   <table width="400" border="0" align="center" cellpadding="10" cellspacing="2">
                    <tbody>
                      <tr>
                        <td colspan="2" style="text-align: center"> Login Form </td>
                      </tr>
                      <tr>
                        <td>Username</td>
                        <td> <input type="text" name="username" id="username"> </td>
                      </tr>
                      <tr>
                        <td>Password</td>
                        <td> <input type="password" name="password" id="password"> </td>
                      </tr>
                      <tr>
                         <td>&nbsp;</td>
                         <td><input type="submit" name="submit" id="submit" value="Submit"></td>
                      </tr>
                     </tbody>
                    </table>
                  <p>&nbsp;</p>
                </form></td>
                </tr>
            </tbody>
          </table></td>
        </tr>
        <tr>
          <td bgcolor="#FFFFFF"><?php include("footer.php"); ?></td>
        </tr>
      </tbody>
    </table>
   </div>
 </body>
</html>

<?php 
if($_SERVER["REQUEST_METHOD"] == "POST")
{
	//establish connection
	include ("myconn.php");
	
	//accept the values from user form
	$uname=$_REQUEST["username"];
	$pass=$_REQUEST["password"];
	
	$sql = "SELECT * from adminlogin where username = '$uname' and password = '$pass'";
	$result = $conn->query($sql);
	if($result->num_rows == 1)
	{
		  echo "Login Successfull";
	}
	else
	{
		echo "Invalid username or password";
	}
}

?>