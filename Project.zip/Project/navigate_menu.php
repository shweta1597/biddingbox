<ul>
  <li><a href="index.php">Home</a></li>
  <li><a href="about.php">About</a></li>
  <li class="dropdown">
    <a href="javascript:void(0)" class="dropbtn">Login</a>
    <div class="dropdown-content">
      <a href="adminlogin.php">Admin</a>
      <a href="userlogin.php">User</a>
      <a href="businessownerlogin.php">Business Owner</a>
    </div>
  </li>
</ul>



