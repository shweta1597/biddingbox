<table width="1000" border="0" cellspacing="0" cellpadding="0">
 <tbody>
  <tr>
   <td width="1000" height="30" bgcolor="#575353" style="font-family: Arial; text-align: center; font-weight: bold; color: #FFEAEA; font-style: normal; font-size: 12px;"> Project registered to Bidding Box </td>
  </tr>
 </tbody>
</table>