<!doctype html>
 <html>
  <head>
   <meta charset="utf-8">
	<title> Home </title>
	 <link href="menustyle.css" rel="stylesheet" type="text/css">
	  <style type="text/css">
		body 
		{
			background-image: url(code-wallpaper-24.jpg);
			margin-left: 2px;
			margin-top: 2px;
			margin-right: 2px;
			margin-bottom: 2px;
		}
      </style>
   </head>
   <body>
    <p>&nbsp;</p>
    <div class="container">
     <table align="center" width="1000" border="0" cellspacing="0" cellpadding="0">
      <tbody>
        <tr>
          <td bgcolor="#FFFFFF"> <?php include("header.php"); ?></td>
        </tr>
        <tr>
          <td bgcolor="#FFFFFF"> <?php include("navmenu.php"); ?></td>
        </tr>
        <tr>
          <td bgcolor="#FFFFFF">
           <table width="1000" border="0" cellspacing="0" cellpadding="10">
            <tbody>
              <tr>
                <td><form id="form1" name="form1" method="post">
                 <p>&nbsp;</p>
                  <table width="400" border="0" align="center" cellpadding="10" cellspacing="2" >
                  
                  <p> Bidding Box is a marketplace where people who need custom software developed can find coders in a safe and business-friendly environment. Buyers can pick from a pool of registered coders. Enabling them to hire the coders across the country or across the globe from the comfort of their computers. Buyers who wish to hire internationally, can take advantage of favorable overseas exchange rates, resulting in work being done for 50-90% less than if the project were done in-country. Coders are also given access to a huge pool of potential work and have the ability to work independently from their homes rather than from a company. Coders and buyers both can be benefited from this Bidding.   
                  
 In the current world, there will be a definite need of software in order to make their day to day activities, in an unavoidable way. Out of these needy business activities, most of them may not be able to approach big software consulting firms. In order to help people in their business activities we have developed software called Bidding Box.  </p>

<p> In this software, the administrator facilitates the registration of the buyer and coder. It also provides login facilities. The coder has to post the profile with the prescribed information. The coder has to bid for the project online based on the expertise and once if the bid is approved the coder can start coding based upon the requirements prescribed by the user and provide the software on timelines and get a bided remuneration. The buyer can post the project. While posting a project for bidding, the buyer has to furnish the information related to technology used in the project and the expected timelines for each deliverable. The buyer allocates projects to the coders based on the bid. Both coders and buyers can interact with each other and the cost of the project reduces as the concept of biding is used. </p>
                  
<p> The best coder can be recognized by his highest biding, timeline he has used, reviews and public rating for the prescribed software. </p>

                  </table>
                 <p>&nbsp;</p>
                </form></td>
                </tr>
            </tbody>
          </table></td>
        </tr>
        <tr>
          <td bgcolor="#FFFFFF"> <?php include("footer.php"); ?></td>
        </tr>
      </tbody>
    </table>
   </div>
  </body>
</html>