<ul>
  <li><a href="userindex.php">Home</a></li>
  <li class="dropdown">
    <a href="javascript:void(0)" class="dropbtn">Settings</a>
    <div class="dropdown-content">
      <a href="userchangepassword.php">Change Password</a>
  <li><a href="userlogout.php">Logout</a></li>
  
</ul>



