<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Untitled Document</title>
<style type="text/css">
body {
	background-image: url(images/background.jfif);
	text-align: center;
}

</style>
<link href="navigate_menu.css" rel="stylesheet" type="text/css">
</head>


<body>
<table width="1100" border="0" align="center" cellpadding="0" cellspacing="0">
  <tbody>
    <tr>
      <td bgcolor="#FFFFFF">&nbsp;</td>
    </tr>
    <tr>
      <td bgcolor="#FFFFFF">&nbsp;</td>
    </tr>
    <tr>
      <td bgcolor="#FFFFFF"><table width="1100" border="0" cellspacing="0" cellpadding="10">
        <tbody>
<tr>
  <td bgcolor="#FFFFFF">&nbsp;</td>
  </tr>
  <table width="1100" border="0" cellpadding="0" cellspacing="0">
    <tbody>
      <tr>
        <td bgcolor="#FFFFFF"><?php include("header.php"); ?></td>
      </tr>
      <tr>
        <td bgcolor="#FFFFFF"><?php include("navigate_menu.php"); ?></td>
      </tr>
      <tr>
        <td bgcolor="#FFFFFF">
		  <?php

   //establish a connection with database
  include("myconn.php");
  //accept the values from user form and then store it in variables
  $full_name = $_REQUEST["fullname"];
  $email = $_REQUEST["email"];
  $mobile_number = $_REQUEST["mobileno"];
  $address = $_REQUEST["address"];
  $user_name = $_REQUEST["uname"];
  $password = $_REQUEST["pass"];
  $conpassword = $_REQUEST["conpass"];
	
	$sql = "SELECT * from visitor where user_name = '$user_name'";
	$result = $conn->query($sql);
	if($result->num_rows >0)
	{
			echo "</br> User Already Registered";
	}
	else if($result->num_rows ==0)
	{
		 //create a insert query
		
		$insertquery="INSERT INTO visitor (full_name,email,mobile_number,address,user_name,password) values('$full_name','$email','$mobile_number','$address','$user_name','$password')";
  
			  //execute the query
			  if ($conn->query($insertquery) === TRUE) 
			  {
				  echo "</br> Registration Successfull";
			  } 
			  else 
			  {
				echo "Error: " . $conn->error;
			  }
	}
  	else
	{
		echo "Error: " . $conn->error;
	}


  //create a insert query
  

	//close the connection
	$conn->close();
  
 
?>
			<p><a href="userlogin.php">Click Here to Go Back</a></p>
		  </td>
      </tr>
		
      <tr>
        <td bgcolor="#FFFFFF"><?php include("footer.php"); ?></td>
      </tr>
    </tbody>
  </table>
</body>
</html>
