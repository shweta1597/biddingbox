<div class="navbar">
 <a href="home.php"> Home </a>
 <a href="aboutus.php"> Search Projects </a> 
  <div class="dropdown">
    <button class="dropbtn"> Settings
    <i class="fa fa-caret-down"></i>
    </button>
    <div class="dropdown-content">
  	 <a href="coder_changepass.php"> Change Password </a>
    </div>
    </div>
  <a href="coderlogout.php"> Logout </a>
</div>
