<div class="navbar">
 <a href="home.php"> Home </a>
 <a href="newproject.php"> Host A Project </a> 
 <div class="dropdown">
    <button class="dropbtn"> My Projects 
    <i class="fa fa-caret-down"></i>
    </button>
    <div class="dropdown-content">
  	 <a href="buyer_changepass.php"> View Hosted Projects </a>
     <a href="update_buyer.php"> View Bids</a>
    </div>
  </div>
  <div class="dropdown">
    <button class="dropbtn"> Settings
    <i class="fa fa-caret-down"></i>
    </button>
    <div class="dropdown-content">
  	 <a href="buyer_changepass.php"> Change Password </a>
     <a href="update_buyer.php"> Update Profile </a>
    </div>
    </div>
  	 <a href="buyerlogout.php"> Logout </a>
</div>
