<ul>
  <li><a href="businessindex.php">Home</a></li>
  <li><a href="business.php">New Business</a></li>
   <li><a href="businessownerchangepassword.php">Change Password</a></li>
  <li><a href="businessownerlogout.php">Logout</a></li>
</ul>