<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Untitled Document</title>
</head>

<body>
<form id="form1" name="form1" method="post">
  <p><strong>WELCOME TO
  </strong></p>
  <p>&nbsp;</p>
  <p><img src="medo.png" width="800" height="216" alt=""/></p>
  <p>&nbsp;</p>
  <a href="logout.php">
  <p><strong style="font-size: xx-large">Logout</strong></p>
  </a>
  <p>&nbsp;</p>
</form>
</body>
</html>