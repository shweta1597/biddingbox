<?php 
session_start();
ob_start();
if(!isset($_SESSION["cuname"]))
{
	header("location:coderlogin.php");
}

?>
<!doctype html>
 <html>
  <head>
   <meta charset="utf-8">
    <title> Coder Dashboard </title>
	 <link href="menustyle.css" rel="stylesheet" type="text/css">
	  <style type="text/css">
	   body 
	   {
			background-color: #A08A8A;
			text-align: justify;
			background-image: url(code-wallpaper-24.jpg);
	   }
	  </style>
  </head>
  <body>
   <p>&nbsp;</p>
    <div class="container">
      <table align="center" width="1000" border="0" cellspacing="0" cellpadding="0">
        <tbody>
          <tr>
            <td bgcolor="#FFFFFF"> <?php include("header.php"); ?></td>
          </tr>
          <tr>
            <td bgcolor="#FFFFFF"> <?php include("coder_menu.php"); ?></td>
          </tr>
          <tr>
            <td bgcolor="#FFFFFF">
             <table width="1000" border="0" cellspacing="0" cellpadding="10">
              <tbody>
                <tr>
                  <td>
                    <p>&nbsp;</p>
                    <table width="920" border="2" cellspacing="0" cellpadding="10">
                      <tbody>
                        <tr>
                        <td width="153"> Full Name </td>
                          <td width="175"> DOB </td>
                          <td width="175"> Email </td>
                          <td width="175"> Mobile No. </td>
                          <td width="142"> Address </td>
                          <td width="76"> Skills </td>
                          <td width="95"> Username </td>
                          <td width="51"> Edit </td>
                          <td width="70"> Delete </td>
                        </tr>
                         <?php
						include("myconn.php");
						$sql="SELECT *from coderlogin";
						$result=$conn->query($sql);
						while($row=$result->fetch_assoc())
						{
							$fullname=$row["fullname"];
							?>
	
							<tr>
							  <td height="42"> <?php echo $row["fullname"];?> </td>
                                <td> <?php echo $row["dateofbirth"];?> </td>
								<td> <?php echo $row["email"];?> </td>
                                <td> <?php echo $row["mobileno"];?> </td>
								<td> <?php echo $row["address"];?> </td>
								<td> <?php echo $row["skills"];?> </td>
								<td> <?php echo $row["username"];?> </td>
							  <td> Edit </td>
							  <td> Delete </td>
							</tr>
							<?php
						}
                             ?>
                     </tbody>
                    </table>
                    <p>&nbsp;</p>
                  <p>&nbsp;</p></td>
                  </tr>
                </tbody>
              </table></td>
          </tr>
          <tr>
            <td bgcolor="#FFFFFF"> <?php include("footer.php"); ?></td>
          </tr>
        </tbody>
      </table>
   </div>
  </body>
 </html>