<!doctype html>
 <html>
  <head>
   <meta charset="utf-8">
    <title> Coder Register </title>
	 <style type="text/css">
        body 
        {
            background-image: url(code-wallpaper-24.jpg);
        }
     </style>
    <link href="menustyle.css" rel="stylesheet" type="text/css">
    <link href="jQueryAssets/jquery.ui.core.min.css" rel="stylesheet" type="text/css">
    <link href="jQueryAssets/jquery.ui.theme.min.css" rel="stylesheet" type="text/css">
    <link href="jQueryAssets/jquery.ui.datepicker.min.css" rel="stylesheet" type="text/css">
    <script src="jQueryAssets/jquery-1.11.1.min.js" type="text/javascript"></script>
    <script src="jQueryAssets/jquery.ui-1.10.4.datepicker.min.js" type="text/javascript"></script>
    <script language="javascript">
		function validate()
		{
			pass=document.getElementById("password");
			cpass=document.getElementById("confirmpassword");
			if(pass.value.trim()!=cpass.value.trim())
			{
				alert('Password Mismatch');
				cpass.focus();
				return false;
			}
		}
	</script>
  </head>
  <body>
    <div class="container">
      <table align="center" width="1000" border="0" cellspacing="0" cellpadding="0">
       <tbody>
        <tr>
          <td bgcolor="#FFFFFF"><?php include("header.php"); ?></td>
        </tr>
        <tr>
          <td bgcolor="#FFFFFF"><?php include("navmenu.php"); ?></td>
        </tr>
        <tr>
          <td bgcolor="#FFFFFF">
           <table width="1000" border="0" cellspacing="0" cellpadding="10">
            <tbody>
             <tr>
              <td><form id="form1" name="form1" method="post" onSubmit="return validate()" enctype="multipart/form-data">
        	   <p>&nbsp;</p>
          	    <table width="461" border="0" align="center" cellpadding="5" cellspacing="10">
                 <tbody>
                  <tr>
                    <td colspan="3" style="text-align: center">Registration Form</td>
                  </tr>
                  <tr>
                	<td width="154">Full Name</td>
                	<td colspan="2"><input name="fullname" type="text" required="required" id="fullname"></td>
              	  </tr>
                  <tr>
                    <td>DOB</td>
                    <td colspan="2"><input name="dateofbirth" type="text" id="dateofbirth"></td>
                  </tr>
                  <tr>
                    <td>Email</td>
                    <td colspan="2"><input name="email" type="email" required="required" id="email"></td>
                 </tr>
                  <tr>
                    <td>Mobile No. </td>
                    <td colspan="2"><input name="mobileno" type="text" required="required" id="mobileno"></td>
                  </tr>
                  <tr>
                   <td>Address</td>
                   <td colspan="2"><textarea name="address" required id="address"></textarea></td>
                 </tr>
                 <tr>
                  <td>Skills</td>
                  <td width="110"><p>
                   <label>
                    <input type="checkbox" name="skills[]" value="C" id="skills_0">
                    C</label>
                  <br>
                  <label>
                    <input type="checkbox" name="skills[]" value="C++" id="skills_1">
                    C++</label>
                  <br>
                  <label>
                    <input type="checkbox" name="skills[]" value="Java" id="skills_2">
                    Java</label>
                  <br>
                  <label>
                    <input type="checkbox" name="skills[]" value="Shellscript" id="skills_3">
                    Shell script</label>
                  <br>
                  <label>
                    <input type="checkbox" name="skills[]" value="Unix" id="skills_4">
                    Unix</label>
                  <br>
                  <label>
                    <input type="checkbox" name="skills[]" value="Linux" id="skills_5">
                    Linux</label>
                  <br>
                </p></td>
                  <td width="127"><label>
                    <input type="checkbox" name="skills_" value="VB.Net" id="skills_6">
                    VB.NET</label>
                    <br>
                    <label>
                      <input type="checkbox" name="skills_" value="C#.Net" id="skills_7">
                      C#.NET</label>
                    <br>
                    <label>
                      <input type="checkbox" name="skills_" value="HTML" id="skills_8">
                      HTML</label>
                    <br>
                    <label>
                      <input type="checkbox" name="skills_" value="CSS" id="skills_9">
                      CSS</label>
                    <br>
                    <label>
                      <input type="checkbox" name="skills_" value="ASP.NET" id="skills_10">
                      ASP.NET</label>
                    <br>
                    <label>
                      <input type="checkbox" name="skills_" value="Python" id="skills_11">
                      Python</label>
                    <br>
                    <label>
                      <input name="skills_" type="checkbox" id="skills_12" value="Ruby">
                      Ruby</label></td>
                 </tr>
              <tr>
                <td>Username</td>
                <td colspan="2"><input name="username" type="text" required="required" id="username"></td>
              </tr>
              <tr>
                <td>Password</td>
                <td colspan="2"><input name="password" type="password" required="required" id="password"></td>
              </tr>
              <tr>
                <td>Confirm Password</td>
                <td colspan="2"><input name="confirmpassword" type="password" required="required" id="confirmpassword"></td>
              </tr>
              <tr>
                <td>&nbsp;</td>
                <td colspan="2"><input type="submit" name="submit" id="submit" value="submit"></td>
              </tr>
            </tbody>
           </table>
          <p>&nbsp;</p>
        </form>
       </td>
      </tr>
     </tbody>
    </table>
   </td>
  </tr>
      <tr>
        <td bgcolor="#FFFFFF"> <?php include("footer.php"); ?> </td>
     </tr>
    </tbody>
   </table>
  </div>
  <script type="text/javascript">
$(function() {
	$( "#dateofbirth" ).datepicker(); 
});
    </script>
 </body>
</html>

<?php 
	
	if($_SERVER["REQUEST_METHOD"] == "POST")
	{
		$fullname=$_REQUEST["fullname"];
		$dob=$_REQUEST["dateofbirth"];
		$email=$_REQUEST["email"];
		$mobno=$_REQUEST["mobileno"];
		$address=$_REQUEST["address"];
		$skills=$_REQUEST["skills"];
		$uname=$_REQUEST["username"];
		$pass=$_REQUEST["password"];
		$cpass=$_REQUEST["confirmpassword"];
		
		include("myconn.php");
		
		 if(isset($_POST['submit']))
		 {
			$checkbox1=$_POST['skills'];
			$chk="";
			foreach($checkbox1 as $chk1)
			{
				$chk .= $chk1.",";
			}			
		 }		
		$sql="Select * from coderlogin where username='$uname'";
		$result = $conn->query($sql);
		if($result->num_rows >=1 )
		{
			  echo "<script> alert('Coder Already Registered') </script>";
		}
		else if($result->num_rows ==0 )
		{
				$insertquery = "INSERT INTO coderlogin(fullname,dateofbirth,email,mobileno,address,skills,username,password) values('$fullname','$dob','$email','$mobno','$address','$chk','$uname','$pass')";
				   
				if($conn->query($insertquery)===TRUE)
				{
					echo "<script> alert('Registration successful') </script> ";
				}
				else
				{
					echo "Error : " . $sql . "<br>" . $conn->error;
				}
		}
		else
		{
			echo "Error : " . $sql . "<br>" . $conn->error;
		}
		
	$conn->close();
	}
?>