<div class="navbar">
 <a href="home.php"> Home </a>
 <a href="manage_coders.php"> Manage coders </a>
 <a href="manage_buyers.php"> Manage buyers </a>
 <a href="aboutus.php"> Manage Projects </a> 
  <div class="dropdown">
    <button class="dropbtn"> Settings
    <i class="fa fa-caret-down"></i>
    </button>
    <div class="dropdown-content">
  	 <a href="admin_changepass.php"> Change Password </a>
    </div>
    </div>
  <a href="adminlogout.php"> Logout </a>
</div>
