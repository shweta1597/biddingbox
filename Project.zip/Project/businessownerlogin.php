<?php
//start the session
session_start();
ob_start();
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
<style type="text/css">

body {
	background-image: url(images/background.jfif);
	background-color: #FFFFFF;
}
</style>
<link href="navigate_menu.css" rel="stylesheet" type="text/css">
<style type="text/css">
body,td,th {
	color: #000000;
}
</style>
</head>

<body>

<table width="1000" border="0" align="center" cellpadding="0" cellspacing="0">

  <tbody>
     <tr>
      <td bgcolor="#FDFDFD">
      <table width="1102" border="0" cellspacing="0" cellpadding="10">
    
        <tbody> <a href="business.php"> </a>
        <form id="frm" name="frm" method="post" >
          <table width="1100" border="0" align="center" cellpadding="0" cellspacing="0">
          <tbody>
            <tr>
              <td bgcolor="#FFFFFF"><?php include("header.php"); ?></td>
              </tr>
              <tr>
                <td bgcolor="#FFFFFF"><?php include("navigate_menu.php"); ?></td>
              </tr>
              <tr>
                <td bgcolor="#FFFFFF"><table width="1000" border="0" align="center" cellpadding="10" cellspacing="0">
                  <tr>
                    <td colspan="3">&nbsp;</td>
                  </tr>
                  <tr>
                    <td width="384" rowspan="5"><img src="images/businessowner2.jfif" width="258" height="156" alt=""/></td>
                    <td width="132"><label for ="uname2">Username</label></td>
                    <td width="424"><input name="uname" type="text" required="required" id="uname2" pattern="[a-z]{1,20}" title="Only lower case letters and minimum 1 maximum 20 characters" /></td>
                  </tr>
                  <tr>
                    <td><label for ="pass">Password</label></td>
                    <td><input name="pass" type="password" required="required" id="pass" pattern="[a-zA-Z0-9@$#!]{8,20}" title="lower case,upper case,@,$,#,! special symbols and minimum 8 maximum 20 characters" /></td>
                  </tr>
                  <tr>
                    <td>&nbsp;</td>
                    <td><input type="submit" name="SignIn" id="SignIn" value="Sign In" /></td>
                  </tr>
                  <tr>
                    <td>&nbsp;</td>
                    <td>Forgot Password?</td>
                  </tr>
                  <tr>
                    <td><a href="businessowner.php"></a></td>
                    <td><a href="businessowner.php">New Business Owner ? Register</a></td>
                  </tr>
                </table></td>
              </tr>
              <tr>
                <td bgcolor="#FFFFFF"><?php include("footer.php"); ?></td>
              </tr>
            </tbody>
          </table>
        </form>
           
        
</body>
</html>

<?php
if($_SERVER["REQUEST_METHOD"] == "POST")
{
	//establish connection
	include ("myconn.php");
	
	//accept the values from user form
	$uname=$_REQUEST["uname"];
	$pass=$_REQUEST["pass"];
	
	$sql = "SELECT * from businessowner where username = '$uname' and password = '$pass'";
	$result = $conn->query($sql);
	if($result->num_rows == 1)
	{
		  //create a session object name uname and assign username to it.
		  $_SESSION["uname"]=$uname;
		  
		  //redirect the control from login page to dashboard page.
		  header("location:businessindex.php");
	}
	else
	{
		echo "<script> alert('Invalid username or password')</script>";
	}
}
?>