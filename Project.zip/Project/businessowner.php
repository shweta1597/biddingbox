<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Untitled Document</title>
<style type="text/css">

body {
	background-image: url(images/background.jfif);
	text-align: center;
	background-color: #FFFFFF;
}
</style>
<link href="navigate_menu.css" rel="stylesheet" type="text/css">
<style type="text/css">
body,td,th {
	color: #050505;
}
</style>
</head>

<body>
<table width="1000" border="0" align="center" cellpadding="0" cellspacing="0">
  <tbody>
              <tr>
                <td bgcolor="#FFFFFF"><?php include("header.php"); ?></td>
              </tr>
              <tr>
                <td bgcolor="#FFFFFF"><?php include("navigate_menu.php"); ?></td>
              </tr>
              <tr>
                <td bgcolor="#FFFFFF"><form action="businessowner_back.php" method="post" name="form1" id="form1">
					<table width="400" border="0" align="center" cellpadding="10" cellspacing="0">
                  <tbody>
                    <tr>
                      <td colspan="2"><strong style="font-size: 24px">Business Owner Registration Form</strong></td>
                    </tr>
                    <tr>
                      <td>First Name</td>
                      <td><input name="firstname" type="text" required="required" id="firstname" pattern="[a-zA-Z\s]+" title="Accepts lower case, upper case and space"></td>
                    </tr>
                    <tr>
                      <td width="151">Last Name</td>
                      <td width="205"><input name="lastname" type="text" required id="lastname" pattern="[a-zA-Z\s]+" title="Accepts lower case, upper case and space"></td>
                    </tr>
                    <tr>
                      <td><label>Email</label></td>
                      <td><input name="email" type="email" required="required" id="email" title="eg: xyz@gmail.com"></td>
                    </tr>
                    <tr>
                      <td><p>Mobile No</p></td>
                      <td><input name="mobileno" type="text" required id="mobileno" pattern="(9|8|7)\d{9}" title="Number starts from 9 or 8 or 7 and 10 characters are required"></td>
                    </tr>
                    <tr>
                      <td>Username</td>
                      <td><input name="username" type="text" required id="username" pattern="[a-z]{1,20}" title="Only lower case letters and minimum 1 maximum 20 characters"></td>
                    </tr>
                    <tr>
                      <td>Password</td>
                      <td><input name="password" type="password" required id="password" pattern="[a-zA-Z0-9@$#!]{8,20}" title="lower case,upper case,@,$,#,! special symbols and minimum 8 maximum 20 characters"></td>
                    </tr>
                    <tr>
                      <td>Confirm Password</td>
                      <td><input name="conpassword" type="password" required id="conpassword" pattern="[a-zA-Z0-9@$#!]{8,20}" title="lower case,upper case,@,$,#,! special symbols and minimum 8 maximum 20 characters"></td>
                    </tr>
                    <tr>
                      <td>&nbsp;</td>
                      <td><input name="Register" type="submit" id="Register" value="Register"></td>
                    </tr>
                  </tbody>
                </table>
			 </form>
			</td>
           </tr>
             <tr>
                <td bgcolor="#FFFFFF"><?php include("footer.php"); ?></td>
              </tr>
            </tbody>
          </table>
</body>
</html>