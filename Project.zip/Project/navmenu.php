<div class="navbar">
 <a href="home.php"> Home </a>
 <a href="aboutus.php"> About us </a>
  <div class="dropdown">
    <button class="dropbtn"> Login
      <i class="fa fa-caret-down"></i>
    </button>
    <div class="dropdown-content">
      <a href="adminlogin.php"> Admin </a>
      <a href="buyerlogin.php"> Buyer </a>
      <a href="coderlogin.php"> Coder </a>
    </div>
  </div> 
</div>
