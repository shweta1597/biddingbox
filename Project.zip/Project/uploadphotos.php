<?php
if($_SERVER['REQUEST_METHOD']=="POST")
{
	$error=array();
	$file_name=$_FILES['profilephoto']['name'];
	$file_size=$_FILES['profilephoto']['size'];
	$file_name=$_FILES['profilephoto']['tmp_name'];
	$file_name=$_FILES['profilephoto']['type'];
	
	$allowed = array("jpg" => "image/jpg", "jpeg" => "image/jpeg", "gif" => "image/gif","png" => "image/png");

	//Verify file extension
	$ext = pathinfo($file_name, PATHINFO_EXTENSION);
	
	if(!array_key_exists($ext,$allowed))
		die("Error: Please select a valid file format.");
	
	move_uploaded_file($file_tmp,"uploads/".$file_name);
}
?>