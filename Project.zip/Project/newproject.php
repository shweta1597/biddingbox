<?php 
session_start();
ob_start();
if(!isset($_SESSION["buname"]))
{
	header("location:buyerlogin.php");
}

?>
<!doctype html>
 <html>
  <head>
   <meta charset="utf-8">
    <title> Buyer Dashboard </title>
	 <link href="menustyle.css" rel="stylesheet" type="text/css">
	  <style type="text/css">
	   body 
	   {
			background-color: #A08A8A;
			text-align: justify;
			background-image: url(code-wallpaper-24.jpg);
	   }
	  </style>
  </head>
  <body>
   <p>&nbsp;</p>
    <div class="container">
      <table align="center" width="1000" border="0" cellspacing="0" cellpadding="0">
        <tbody>
          <tr>
            <td bgcolor="#FFFFFF"> <?php include("header.php"); ?></td>
          </tr>
          <tr>
            <td bgcolor="#FFFFFF"> <?php include("buyer_menu.php"); ?></td>
          </tr>
          <tr>
            <td bgcolor="#FFFFFF">
             <table width="1000" border="0" cellspacing="0" cellpadding="10">
              <tbody>
                <tr>
                  <td>Welcome <?php echo  $_SESSION['buname']; ?></td>
                </tr>
                <tr>
                  <td>
                    <p>&nbsp;</p>
                    <form method="post" enctype="multipart/form-data" name="form1" id="form1">
                      <table width="500" border="0" align="center" cellpadding="10" cellspacing="0">
                        <tbody>
                          <tr>
                            <td colspan="2"><strong style="text-align: center">Host a new Project</strong></td>
                          </tr>
                          <tr>
                            <td width="191">Project Name</td>
                            <td width="269"><input name="textfield" type="text" id="textfield" size="50"></td>
                          </tr>
                          <tr>
                            <td>Short Description</td>
                            <td><textarea name="textarea" cols="50" rows="5" id="textarea"></textarea></td>
                          </tr>
                          <tr>
                            <td>Project Type</td>
                            <td><select name="select" id="select">
                              <option value="-1">Select Type</option>
                              <option value="Mobile Application">Mobile Application</option>
                              <option value="Website">Website</option>
                              <option value="Web Application">Web Application</option>
                              <option value="Desktop Application">Desktop Application</option>
                            </select></td>
                          </tr>
                          <tr>
                            <td>Technologies To Be Used</td>
                            <td><textarea name="textarea2" id="textarea2"></textarea></td>
                          </tr>
                          <tr>
                            <td>Estimated Project Cost</td>
                            <td><input type="text" name="textfield2" id="textfield2"></td>
                          </tr>
                          <tr>
                            <td>Project Duration  </td>
                            <td><input type="number" name="number" id="number"></td>
                          </tr>
                          <tr>
                            <td>Requirement File</td>
                            <td><input type="file" name="fileField" id="fileField"></td>
                          </tr>
                          <tr>
                            <td>Bidding Starts From</td>
                            <td><input type="date" name="date" id="date"></td>
                          </tr>
                          <tr>
                            <td>Bidding Ends On</td>
                            <td><input type="date" name="date2" id="date2"></td>
                          </tr>
                          <tr>
                            <td>Min Tender Amount</td>
                            <td>&nbsp;</td>
                          </tr>
                          <tr>
                            <td>Bid </td>
                            <td>&nbsp;</td>
                          </tr>
                          <tr>
                            <td>&nbsp;</td>
                            <td><input type="submit" name="submit" id="submit" value="Submit"></td>
                          </tr>
                        </tbody>
                      </table>
                    </form>
                    <p> 
                    <h1 align="center">&nbsp;</h1>  
                    </p>
                    <p>&nbsp;</p>
                  </td>
                  </tr>
              	</tbody>
              </table></td>
          </tr>
          <tr>
            <td bgcolor="#FFFFFF"> <?php include("footer.php"); ?></td>
          </tr>
        </tbody>
      </table>
   </div>
  </body>
 </html>