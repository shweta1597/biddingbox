<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Untitled Document</title>
<style type="text/css">

body {
	background-image: url(images/background.jfif);	
}
p {
	line-height: 1.5em;
	font-size: 16px;
	font-family: arial;
	font: 14px;
}
</style>
<link href="navigate_menu.css" rel="stylesheet" type="text/css">
<style type="text/css">
body,td,th {
	font-size: 16px;
	color: #1A1515;
}
</style>
</head>

<body>
<table width="1000" border="0" align="center" cellpadding="0" cellspacing="0">
  <tbody>
    <tr>
      <td bgcolor="#FFFFFF"><?php include("header.php"); ?></td>
    </tr>
    <tr>
      <td bgcolor="#FFFFFF"><?php include("navigate_menu.php"); ?></td>
    </tr>
    <tr>
      <td bgcolor="#FFFFFF"><table width="1102" border="0" cellspacing="0" cellpadding="10">
        <tbody>
<table width="1000" border="0" cellspacing="0" cellpadding="0">
  <tbody>
     <tr>
      <td bgcolor="#FFFFFF"><table width="1200" border="0" align="center" cellpadding="10" cellspacing="0">
        <tbody>
          <tr>
            <td bgcolor="#FFFFFF"><p><strong><span style="text-align: center">
              <span style="text-align: justify">Shopping Guide is a one-stop shopping portal for India which will serve as an online guide for all your offline shopping needs!! This site is not about online shopping. It is a portal devoted to shopping.
                It seeks to help tourists, visitors and residents in the best markets and shops India has to offer across popular cities.
                
                Shopping on your own in a new city can be a crazy experience. What if you had a friend who could take you on a personalized Belagavi Shopping Tour. </span></span></strong></p>
              <p><strong><span style="text-align: center"><span style="text-align: justify">Have you ever shopped all day through winding bazaars wondering which shops sell authentic products? Or wondered where you could get that product which you required.
                
                Here is the solution for your problem and that is Shopping Guide.
                
                Shopping Guide provides information on the best quality shops for user in Belagavi, the best markets and the best malls. We simplify the search for shops in a city by identifying the best shops in different product categories and give users all relevant information on such shops. We provide product and maps, as well as directions to the shops. Get all the scoops – right here on Shopping Guide.
                
                </span></span></strong></p>
              <p><strong><span style="text-align: center"><span style="text-align: justify">This project helps you to search and find shops within a city, an area, a product category, so you know where to go and what to buy before you set out to shop. Based on personal reviews and experiences of users in each city, we have provided simple qualitative information on shops and also a fantastic map for you to find the shops easily. Accompanied by Google map directions, how-to-get-there and specific shop-timings – we are sure that our site will simplify your search and enhance your shopping experience. </span></span></strong> <span style="text-align: justify">&nbsp;</span></p></td>
          </tr>
          </tbody>
      </table></td>
    </tr>
    <tr>
      <td bgcolor="#FFFFFF"><?php include("footer.php"); ?></td>
    </tr>
  </tbody>
</table>
</body>
</html>