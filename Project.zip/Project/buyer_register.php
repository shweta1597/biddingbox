<!doctype html>
 <html>
  <head>
   <meta charset="utf-8">
    <title> Buyer Register </title>
	 <style type="text/css">
        body 
        {
            background-image: url(code-wallpaper-24.jpg);
        }
     </style>
    <link href="menustyle.css" rel="stylesheet" type="text/css">
    <link href="jQueryAssets/jquery.ui.core.min.css" rel="stylesheet" type="text/css">
    <link href="jQueryAssets/jquery.ui.theme.min.css" rel="stylesheet" type="text/css">
    <link href="jQueryAssets/jquery.ui.datepicker.min.css" rel="stylesheet" type="text/css">
    <script src="jQueryAssets/jquery-1.11.1.min.js" type="text/javascript"></script>
    <script src="jQueryAssets/jquery.ui-1.10.4.datepicker.min.js" type="text/javascript"></script>
    <script language="javascript">
	function validate()
	{
		pass=document.getElementById("password");
		cpass=document.getElementById("confirmpassword");
		if(pass.value.trim()!=cpass.value.trim())
		{
			alert('Password Mismatch');
			cpass.focus();
			return false;
		}
	}
	</script>
  </head>
  <body>
  <div class="container">
      <table align="center" width="1000" border="0" cellspacing="0" cellpadding="0">
       <tbody>
        <tr>
          <td bgcolor="#FFFFFF"><?php include("header.php"); ?></td>
        </tr>
        <tr>
          <td bgcolor="#FFFFFF"><?php include("navmenu.php"); ?></td>
        </tr>
        <tr>
          <td bgcolor="#FFFFFF">
           <table width="1000" border="0" cellspacing="0" cellpadding="10">
            <tbody>
             <tr>
              <td><form method="post" enctype="multipart/form-data" name="form1" id="form1" onSubmit="return validate()">
        	   <p>&nbsp;</p>
        	   <table width="424" border="0" align="center" cellpadding="5" cellspacing="10">
          	      <tbody>
                  <tr>
                    <td colspan="2" style="text-align: center">Registration Form</td>
                  </tr>
                  <tr>
                	<td width="154">Full Name</td>
                	<td width="210"><input name="fullname" type="text" required="required" id="fullname" pattern="[a-zA-Z\s]+" title="Accepts lowercase,uppercase &amp; space"></td>
              	  </tr>
                  <tr>
                    <td>Profile photo</td>
                    <td><input type="file" name="profilephoto" id="profilephoto"></td>
                  </tr>
                  <tr>
                    <td>DOB</td>
                    <td><input name="dateofbirth" type="text" id="dateofbirth"></td>
                  </tr>
                  <tr>
                    <td>Email</td>
                    <td><input name="email" type="email" required="required" id="email"></td>
                 </tr>
                  <tr>
                    <td>Mobile No. </td>
                    <td><input name="mobileno" type="text" required="required" id="mobileno" pattern="(9|8|7)\d{9}"></td>
                  </tr>
                  <tr>
                   <td>Address</td>
                   <td><textarea name="address" required id="address"></textarea></td>
                 </tr>
              <tr>
                <td>Username</td>
                <td><input name="username" type="text" required="required" id="username" pattern="[a-z]{1,15}" title="only lowercase min 1 &amp; max 20 characters" maxlength="15"></td>
              </tr>
              <tr>
                <td>Password</td>
                <td><input name="password" type="password" required="required" id="password" pattern="[a-zA-Z0-9@$#!]{8,20}" title="Lowercase, Uppercase @,$,! special symbols min 8 and max 20 characters" maxlength="20"></td>
              </tr>
              <tr>
                <td>Confirm Password</td>
                <td><input name="confirmpassword" type="password" required="required" id="confirmpassword"></td>
              </tr>
              <tr>
                <td>&nbsp;</td>
                <td><input type="submit" name="submit" id="submit" value="submit"></td>
              </tr>
             </tbody>
          </table>
            <p>&nbsp;</p>
      	    <p>&nbsp;</p>
          </form>
         </td>
        </tr>
       </tbody>
      </table>
     </td>
    </tr>
   <p>&nbsp;</p>
   <p>&nbsp;</p>
  </td>
 </tr>
       <tr>
         <td bgcolor="#FFFFFF"> <?php include("footer.php"); ?> </td>
       </tr>
      </tbody>
    </table>
    </td>
   </tr>
  </div>
  <script type="text/javascript">
$(function() {
	$( "#dateofbirth" ).datepicker(); 
});
     </script>
 </body>
</html>

<?php 
	
	if($_SERVER["REQUEST_METHOD"] == "POST")
	{
		$fullname=$_REQUEST["fullname"];
		$dob=$_REQUEST["dateofbirth"];
		$email=$_REQUEST["email"];
		$mobno=$_REQUEST["mobileno"];
		$address=$_REQUEST["address"];
		$uname=$_REQUEST["username"];
		$pass=$_REQUEST["password"];
		$cpass=$_REQUEST["confirmpassword"];
	
		include("myconn.php");
		
		$errors = array();
		$file_name = $_FILES['profilephoto']['name'];
		$file_size = $_FILES['profilephoto']['size'];
		$file_tmp = $_FILES['profilephoto']['tmp_name'];
		$file_type = $_FILES['profilephoto']['type'];
	
		$allowed = array("jpg" => "image/jpg", "jpeg" => "image/jpeg", "gif" => "image/gif", "png" => "image/png", "pdf" => "document/pdf");
	
		// Verify file extension
	
		$ext = pathinfo($file_name, PATHINFO_EXTENSION);
	
		if(!array_key_exists($ext, $allowed)) die("Error: Please select valid file format. ");
		move_uploaded_file($file_tmp,"uploads/".$file_name);
	
		$sql="Select * from buyerlogin where username='$uname'";
		$result = $conn->query($sql);
		if($result->num_rows >=1 )
		{
			  echo "<script> alert('Buyer Already Registered') </script>";
		}
		else if($result->num_rows ==0 )
		{
				$insertquery = "INSERT INTO buyerlogin(fullname,profilephoto,dateofbirth,email,mobileno,address,username,password) values('$fullname','$file_name','$dob','$email','$mobno','$address','$uname','$pass')";
				   
				if($conn->query($insertquery)===TRUE)
				{
				"<script> if(confirm('Registration successful')) window.location='buyerlogin.php';</script>";
				}
				else
				{
					echo "Error : " . $sql . "<br>" . $conn->error;
				}
		}
		else
		{
			echo "Error : " . $sql . "<br>" . $conn->error;
		}
		
	$conn->close();
	}
?>
