<ul>
  <li><a href="adminindex.php">Home</a></li>
 <li class="dropdown">
 <a href="javascript:void(0)" class="dropbtn">View</a>
    <div class="dropdown-content">
  <a href="admindashboard.php">View Admins</a>
  <a href="userdashboard.php">View Registered Users</a>
  <a href="businessownerdashboard.php">View Registered Business Owners</a>
 <li class="dropdown">
    <a href="javascript:void(0)" class="dropbtn">Settings</a>
    <div class="dropdown-content">
      <a href="adminchangepassword.php">Change Password</a>
  <li><a href="adminlogout.php">Logout</a></li>
 
 
</ul>



