<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
<style type="text/css">
#form1 table tr td {
}
</style>
</head>

<body>
<form id="frm" name="frm" method="post" >
  <table width="400" border="0" cellspacing="0" cellpadding="10">
    <tr>
      <td colspan="2"><strong>Login Form</strong></td>
    </tr>
    <tr>
      <td width="126"><label>Username</label></td>
      <td width="234"><label for="uname"></label>
      <input type="text" name="uname" id="uname" /></td>
    </tr>
    <tr>
      <td><label>Password</label></td>
      <td><label for="pass"></label>
      <input type="password" name="pass" id="pass" /></td>
    </tr>
    <tr>
      <td>&nbsp;</td>
      <td><input type="submit" name="SignIn" id="SignIn" value="Sign In" /></td>
    </tr>
    <tr>
      <td>&nbsp;</td>
      <td>Forgot Password?</td>
    </tr>
    <tr>
      <td>&nbsp;</td>
      <td><a href="register.php">New User ? Register Now</a></td>
    </tr>
  </table>
</form>
</body>
</html>

<?php
if($_SERVER["REQUEST_METHOD"] == "POST")
{
	//establish connection
	include ("myconn.php");
	
	//accept the values from user form
	$username=$_REQUEST["uname"];
	$password=$_REQUEST["pass"];
	
	$sql = "SELECT * from student where uname = '$username' and pass = '$password'";
	$result = $conn->query($sql);
	if($result->num_rows == 1)
	{
		  echo "Login Successfull";
	}
	else
	{
		echo "Invalid username or password";
	}
}
?>