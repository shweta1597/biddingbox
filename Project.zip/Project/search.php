<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
</head>

<body>
<form id="form1" name="form1" method="post" action="">
  <table width="287" border="0" align="center">
    <tr>
      <td width="205" height="48"><label for="dname"></label>
      <input name="dname" type="text" id="dname" size="35" /></td>
      <td width="72"><input type="submit" name="submit" id="submit" value="Search" /></td>
    </tr>
  </table>
  <p>&nbsp;</p>
  <p>&nbsp;</p>
  <p>&nbsp;</p>
  <div align="center"></div>
</form>
</body>
</html>

<?php
if($_SERVER['REQUEST_METHOD'] == "POST")
{
	include("myconn.php");
	$sql="SELECT dname,symptom,precuation,solution";


  {
  // Fetch one and one row
  while ($row=mysqli_fetch_row($result))
    {
    printf ("%s (%s)\n",$row[0],$row[1]);
    }
  // Free result set
  mysqli_free_result($result);
 }

 
}

?> 
