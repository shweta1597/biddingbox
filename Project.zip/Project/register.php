<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
</head>

<body>
<form id="form1" name="form1" method="post" action="register_back.php">
  <table width="400" border="0" cellspacing="0" cellpadding="10">
    <tr>
      <td colspan="2">Registration Form</td>
    </tr>
    <tr>
      <td width="154"><label>Roll No</label></td>
      <td width="206"><label for="rollno"></label>
      <input type="text" name="rollno" id="rollno" /></td>
    </tr>
    <tr>
      <td><label>Full Name</label></td>
      <td><label for="fullname"></label>
      <input type="text" name="fullname" id="fullname" /></td>
    </tr>
    <tr>
      <td><label>Course</label></td>
      <td><label for="course"></label>
        <select name="course" id="course">
          <option value="BCA">BCA</option>
          <option value="BSC">BSC</option>
          <option value="BCOM">BCOM</option>
          <option value="MCA">MCA</option>
          <option value="MBA">MBA</option>
          <option value="BBA">BBA</option>
          <option value="MSC">MSC</option>
          <option value="MCOM">MCOM</option>
      </select></td>
    </tr>
    <tr>
      <td><label>Semester</label></td>
      <td><label for="sem"></label>
        <select name="sem" id="sem">
          <option value="1">1</option>
          <option value="2">2</option>
          <option value="3">3</option>
          <option value="4">4</option>
          <option value="5">5</option>
          <option value="6">6</option>
      </select></td>
    </tr>
    <tr>
      <td><label>Email</label></td>
      <td><label for="email"></label>
      <input type="email" name="email" id="email" /></td>
    </tr>
    <tr>
      <td><label>Username</label></td>
      <td><label for="uname"></label>
      <input type="text" name="uname" id="uname" /></td>
    </tr>
    <tr>
      <td><label>Password</label></td>
      <td><label for="conpass"></label>
      <input type="password" name="pass" id="pass" /></td>
    </tr>
    <tr>
      <td><label>Confirm Password</label></td>
      <td><label for="conpass"></label>
      <input type="password" name="conpass" id="conpass" /></td>
    </tr>
    <tr>
      <td>&nbsp;</td>
      <td><input type="submit" name="register" id="register" value="Register" /></td>
    </tr>
  </table>
</form>
</body>
</html>