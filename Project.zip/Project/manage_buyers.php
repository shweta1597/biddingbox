<?php 
session_start();
ob_start();
if(!isset($_SESSION["auname"]))
{
	header("location:adminlogin.php");
}

?>
<!doctype html>
 <html>
  <head>
   <meta charset="utf-8">
    <title> Manage Buyers </title>
	 <link href="menustyle.css" rel="stylesheet" type="text/css">
	  <style type="text/css">
	   body 
	   {
			background-color: #A08A8A;
			text-align: justify;
			background-image: url(code-wallpaper-24.jpg);
	   }
	  </style>
  </head>
  <body>
   <p>&nbsp;</p>
    <div class="container">
      <table align="center" width="1000" border="0" cellspacing="0" cellpadding="0">
        <tbody>
          <tr>
            <td bgcolor="#FFFFFF"> <?php include("header.php"); ?></td>
          </tr>
          <tr>
            <td bgcolor="#FFFFFF"> <?php include("admin_menu.php"); ?></td>
          </tr>
          <tr>
            <td bgcolor="#FFFFFF">
             <table width="1000" border="0" cellspacing="0" cellpadding="10">
              <tbody>
                <tr>
                  <td>
                    <p>&nbsp;</p>
                    <table width="907" border="2" cellspacing="0" cellpadding="10">
                      <tbody>
                        <tr>
                          <td width="149">Full Name</td>
                          <td width="197">Email</td>
                          <td width="186">Address</td>
                          <td width="109">Username</td>
                          <td width="59"> Edit </td>
                          <td width="71"> Delete </td>
                        </tr>
                        <?php
						include("myconn.php");
						$sql="SELECT *from buyerlogin";
						$result=$conn->query($sql);
						while($row=$result->fetch_assoc())
						{
							$fullname=$row["fullname"];
						    ?>
                        <tr>
                          <td><?php echo $row["fullname"];?></td>
                          <td><?php echo $row["email"];?></td>
                          <td><?php echo $row["address"];?></td>
                          <td><?php echo $row["username"];?></td>
                          <td> Edit </td>
                          <td> Delete </td>
                        </tr>
                        <?php
                         }
                            ?>
                      </tbody>
                    </table>
                    <p>&nbsp;</p>
                  <p>&nbsp;</p></td>
                  </tr>
                </tbody>
              </table></td>
          </tr>
          <tr>
            <td bgcolor="#FFFFFF"> <?php include("footer.php"); ?></td>
          </tr>
        </tbody>
      </table>
   </div>
  </body>
 </html>