<?php
session_start();
ob_start();
if(!isset($_SESSION["uname"]))
{
	header("location:userlogin.php");
}
?>
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title></title>
<style type="text/css">
body {
	background-image: url(images/background.jfif);
}
</style>
<link href="navigate_menu.css" rel="stylesheet" type="text/css">
</head>
<body>
<table width="1000" border="0" align="center" cellpadding="0" cellspacing="0">
  <tbody>
    <tr>
      <td bgcolor="#FFFFFF"><?php include("header.php"); ?></td>
    </tr>
    <tr>
      <td bgcolor="#FFFFFF"><?php include("usermenu.php"); ?></td>
    </tr>
    <tr>
      <td bgcolor="#FFFFFF"><table width="1102" border="0" cellspacing="0" cellpadding="10">
        <tbody>
          <tr>
            <td width="1082"><form id="form1" name="form1" method="post">
              <table width="400" border="0" align="center" cellpadding="10" cellspacing="0">
                <tr>
                  <td colspan="2"><label for="oldpass2"><strong>Change Password</strong></label></td>
                </tr>
                <tr>
                  <td>Old Password</td>
                  <td><label for="textfield2"></label>
                    <input name="opass" type="password" required="required" id="opass" pattern="[a-zA-Z0-9@$#!]{8,20}" title="lower case,upper case,@,$,#,! special symbols and minimum 8 maximum 20 characters"></td>
                </tr>
                <tr>
                  <td>New Password</td>
                  <td><input name="npass" type="password" required="required" id="npass" pattern="[a-zA-Z0-9@$#!]{8,20}" title="lower case,upper case,@,$,#,! special symbols and minimum 8 maximum 20 characters"></td>
                </tr>
                <tr>
                  <td>Confirm Password</td>
                  <td><input name="conpass" type="password" required="required" id="conpass" pattern="[a-zA-Z0-9@$#!]{8,20}" title="lower case,upper case,@,$,#,! special symbols and minimum 8 maximum 20 characters"></td>
                </tr>
                <tr>
                  <td width="147">&nbsp;</td>
                  <td width="213"><input type="submit" name="submit" id="submit" value="Submit" /></td>
                </tr>
              </table>
            </form></td>
          </tr>
        </tbody>
      </table></td>
    </tr>
    <tr>
      <td bgcolor="#FFFFFF"><?php include("footer.php"); ?></td>
    </tr>
  </tbody>
</table>
</body>
</html>

<?php
if($_SERVER["REQUEST_METHOD"] == "POST")
{
	//establish connection
	include ("myconn.php");
	
	$uname=$_SESSION["uname"]; //get the username from session variable
	
	//accept the values from user form
	$opass=$_REQUEST["opass"];
	$npass=$_REQUEST["npass"];
	$conpass=$_REQUEST["conpass"];
	
	$sql = "SELECT * from visitor where user_name = '$uname' and password = '$opass'";
	$result = $conn->query($sql);
	if($result->num_rows == 1)
	{
		 $updatequery="update visitor set  password = '$npass' where  user_name = '$uname'";
		 //execute the query
			  if ($conn->query($updatequery) === TRUE) 
			  {
				  echo $conn->error;
				  echo "<script> alert('Password Changed Successfully')</script>";
			  } 
			  else 
			  {
				echo "Error: " . $conn->error;
			  }
	}
	else
	{
		echo $conn->error;
		echo "<script> alert('Invalid username or password')</script>";
	}
}
?>