<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Untitled Document</title>
<style type="text/css">
body {
	background-image: url(images/background.jfif);
	text-align: center;
}
</style>
<link href="navigate_menu.css" rel="stylesheet" type="text/css">
<style type="text/css">
body,td,th {
	color: #020202;
}
</style>
</head>

<body>
<table width="1000" border="0" align="center" cellpadding="0" cellspacing="0">
  <tbody>
    <tr>
      <td bgcolor="#FFFFFF"><?php include("header.php"); ?></td>
    </tr>
    <tr>
      <td bgcolor="#FFFFFF"><?php include("businessownermenu.php"); ?></td>
    </tr>
    <tr>
      <td bgcolor="#FFFFFF">   
        <form id="form1" name="form1" method="post">
          <table width="1080" border="0" cellspacing="0" cellpadding="10">
            <tbody>
              <tr>
                <td colspan="4"><strong style="font-size: 24px; text-align: center;">Business Details</strong></td>
              </tr>
              <tr>
                <td width="198"><label>Business Name</label></td>
                <td width="389"><input name="businessname" type="text" required="required" id="businessname" pattern="[a-zA-Z\s]+" title="Accepts lower case, upper case and space"></td>
                <td width="199">Website</td>
                <td width="214"><input name="website" type="url" required="required" id="website"></td>
              </tr>
              <tr>
                <td>Category</td>
                <td><select name="category" required id="category">
                  <option value="clothing">Clothing</option>
                  <option value="electronics">Electronics</option>
                  <option value="furniture">Furniture</option>
                  <option value="books">Books</option>
                </select></td>
                <td>Working Days</td>
                <td><input name="working_days" type="text" required="required" id="working_days" pattern="[a-zA-Z0-9\s]+" title="Accepts lower case upper case numbers and space"></td>
              </tr>
              <tr>
                <td>Address</td>
                <td><textarea name="address" required id="address"></textarea></td>
                <td>Shop Timing</td>
                <td><input name="timings" type="text" required="required" id="timings" pattern="[a-zA-Z0-9:-\s]" title="Accepts timings eg: 09:00 or -3"></td>
              </tr>
              <tr>
                <td>Area</td>
                <td><input name="area" type="text" required="required" id="area" pattern="[a-zA-Z\s]+" title="Accepts lower case, upper case and space"></td>
                <td>Description</td>
                <td><textarea name="description" required id="description"></textarea></td>
              </tr>
              <tr>
                <td>City</td>
                <td><input name="city" type="text" required="required" id="city" pattern="[a-zA-Z\s]+" title="Accepts lower case, upper case and space"></td>
                <td>&nbsp;</td>
                <td>&nbsp;</td>
              </tr>
              <tr>
                <td>Contact No</td>
                <td><input name="contact_no" type="tel" required="required" id="contact_no" pattern="(9|8|7)\d{9}" title="Number starts from 9 or 8 or 7 and 10 characters are required"></td>
                <td>&nbsp;</td>
                <td>&nbsp;</td>
              </tr>
              <tr>
                <td>Email</td>
                <td><input name="email" type="email" required="required" id="email" title="eg: xyz@gmail.com"></td>
                <td>&nbsp;</td>
                <td>&nbsp;</td>
              </tr>
              <tr>
                <td colspan="4" style="text-align: center">&nbsp;</td>
              </tr>
              <tr>
                <td colspan="4"><span style="text-align: center">
                <input name="Register" type="submit" id="Register" value="Submit">
                </span></td>
              </tr>
            </tbody>
          </table>
        </form>
      </td>
    </tr>
    <tr>
     <td bgcolor="#FFFFFF"><?php include("footer.php"); ?></td>
     </tr>
    </tbody>
    </table>
</body>
</html>
<?php
if($_SERVER["REQUEST_METHOD"] == "POST")
{
   //establish a connection with database
  include("myconn.php");
  //accept the values from user form and then store it in variables
  $bm = $_REQUEST["businessname"];
  $category = $_REQUEST["category"];
  $address = $_REQUEST["address"];
  $area = $_REQUEST["area"];
  $city = $_REQUEST["city"];
  $contact_no = $_REQUEST["contact_no"];
  $email = $_REQUEST["email"];
  $website = $_REQUEST["website"];
  $latitude = $_REQUEST["latitude"];
  $longitude = $_REQUEST["longitude"];
  $working_days = $_REQUEST["working_days"];
  $timings = $_REQUEST["timings"];
  $description = $_REQUEST["description"];
  
  //create a insert query
  $insertquery="INSERT INTO business (business_name,category,address,area,city,contact_no,email,website,latitude,longitude,working_days,timings,description) values('$bm','$category','$address','$area','$city','$contact_no','$email','$website','$latitude','$longitude','$working_days','$timings','$description')";
  
  //execute the query
  if ($conn->query($insertquery) === TRUE) 
  {
     echo "</br> Registration Successfull";
  } 
  else 
  {
    echo "Error: " . $conn->error;
  }


	//close the connection
	$conn->close();
}
 
?>