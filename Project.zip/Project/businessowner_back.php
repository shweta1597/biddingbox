<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Untitled Document</title>
<link href="navigate_menu.css" rel="stylesheet" type="text/css">
</head>

<body>

<p>&nbsp;</p>
<table width="1000" border="0" align="center" cellpadding="0" cellspacing="0">
  <tbody>
    <tr>
      <td bgcolor="#FFFFFF"><?php include("header.php"); ?></td>
    </tr>
    <tr>
      <td bgcolor="#FFFFFF"><?php include("navigate_menu.php"); ?></td>
    </tr>
    <tr>
      <td bgcolor="#FFFFFF"><table width="1000" border="0" cellspacing="0" cellpadding="10">
        <tbody>
          <tr>
            <td width="1082" style="text-align: center"><?php

   //establish a connection with database
  include("myconn.php");
  //accept the values from user form and then store it in variables
  $firstname = $_REQUEST["firstname"];
  $lastname = $_REQUEST["lastname"];
  $email = $_REQUEST["email"];
  $mobileno = $_REQUEST["mobileno"];
  $uname = $_REQUEST["username"];
  $pass = $_REQUEST["password"];
  
  //check if business owner already exists
  $sql = "SELECT * from businessowner where username = '$uname'";
  $result = $conn->query($sql);
	if($result->num_rows >0)
	{
			echo "</br> Business Owner Already Registered";
	}
	else if($result->num_rows ==0)
	{
			//create a insert query
		  $insertquery="INSERT INTO businessowner (firstname,lastname,email,mobileno,username,password) values('$firstname','lastname','$email','$mobileno','$uname','$pass')";

		  //execute the query
		  if ($conn->query($insertquery) === TRUE) 
		  {
			 echo "</br> Registration Successfull";
		  } 
		  else 
		  {
			echo "Error: " . $conn->error;
		  }
	}
  	else{
		echo "Error: " . $conn->error;
	}


	//close the connection
	$conn->close();
  
 
?>
              <p><a href="businessownerlogin.php">Click Here to Go Back</a></p></td>
          </tr>
        </tbody>
      </table></td>
    </tr>
    <tr>
      <td bgcolor="#FFFFFF"><?php include("footer.php"); ?></td>
    </tr>
  </tbody>
</table>
<p>&nbsp;</p>
</body>
</html>